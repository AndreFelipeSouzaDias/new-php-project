<?php

require_once 'Pedido.php';

class Prato {
    private string $nome;
    private float $valor;
    private int $numero;

    public function __construct(string $nome, float $valor, int $numero) {
        $this->nome = $nome;
        $this->valor = $valor;
        $this->numero = $numero;
    }

    public function __toString(): string {
        return "Prato: " . $this->nome . ", Valor: R$: " . $this->valor . ", Número: \n" . $this->numero;
    }

    public function getPreco(): float
    {
        return $this->valor;
    }

    /**
     * Get the value of nome
     */
    public function getNome(): string
    {
        return $this->nome;
    }

    /**
     * Set the value of nome
     */
    public function setNome(string $nome): self
    {
        $this->nome = $nome;

        return $this;
    }

    /**
     * Get the value of valor
     */
    public function getValor(): float
    {
        return $this->valor;
    }

    /**
     * Set the value of valor
     */
    public function setValor(float $valor): self
    {
        $this->valor = $valor;

        return $this;
    }

    /**
     * Get the value of numero
     */
    public function getNumero(): int
    {
        return $this->numero;
    }

    /**
     * Set the value of numero
     */
    public function setNumero(int $numero): self
    {
        $this->numero = $numero;

        return $this;
    }
}